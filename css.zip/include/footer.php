<footer class="full-row bg-secondary p-0">
            <div class="container">
                <div  class="row">
                    <div class="col-lg-12">
                        <div class="divider py-40">
                            <div class="row">
                                <div class="col-md-12 col-lg-4">
                                    <div class="footer-widget mb-4">
                                        <div class="footer-logo mb-4"> <a href="#"><img class="logo-bottom" src="images/logo/logoblack.jpeg" height = "140" alt="image"></a> </div>
                                        <p class="pb-20 text-white">Risus commodo congue augue phasellus morbi hymenaeos ante tincidunt eu orci dictum bibendum lacus platea primis mi lacinia felis gravida natoque bibendum cubilia montes tristique et arcu blandit risus. Lobortis dignissim nam.</p>
										
                                        </div>
                                </div>
                                <div class="col-md-12 col-lg-8">
                                    <div class="row">
                                        <div class="col-md-4 col-lg-4">
                                            <div class="footer-widget footer-nav mb-4">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Support</h4>
                                                <ul class="hover-text-primary">
                                                    <li><a href="#" class="text-white">Forum</a></li>
                                                    <li><a href="#" class="text-white">Terms and Condition</a></li>
                                                    <li><a href="#" class="text-white">Frequenlty Asked Question</a></li>
                                                    <li><a href="contact.php" class="text-white">Contact</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-lg-4">
                                            <div class="footer-widget footer-nav mb-4">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Quick Links</h4>
                                                <ul class="hover-text-primary">
                                                    <li><a href="about.php" class="text-white">About Us</a></li>
                                                    <li><a href="#" class="text-white">Featured Property</a></li>
                                                    <li><a href="#" class="text-white">Submit Property</a></li>
                                                    <li><a href="agent.php" class="text-white">Our Agents</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-lg-4">
                                            <div class="footer-widget">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Contact Us</h4>
                                                <ul class="text-white">
                                                    <li class="hover-text-primary"><i class="fas fa-map-marker-alt text-white mr-2 font-13 mt-1"></i>02 sai street, polokwane</li>
                                                    <li class="hover-text-primary"> <i class="fas fa-phone-alt text-white mr-2 font-13 mt-1"></i>+27 63-626-6610</li>
													<li class="hover-text-primary"> <i class="fas fa-phone-alt text-white mr-2 font-13 mt-1"></i>+27 060 605 0806</li>
                                                    <li class="hover-text-primary"><i class="fas fa-envelope text-white mr-2 font-13 mt-1"></i>baccansaccomodation@gmail.com</li>
                                                </ul>
                                            </div>
                                            <div class="footer-widget media-widget mt-4 text-white hover-text-primary"> <a href="https://www.facebook.com/profile.php?id=61561460843912"><i class="fab fa-facebook-f"></i></a> <a href="https://wa.me/message/LOSL43XFCGJCD1"><i class="fab fa-twitter"></i></a> <a href="#"><i class="fab fa-google-plus-g"></i></a> <a href="#"><i class="fab fa-linkedin-in"></i></a> <a href="#"><i class="fas fa-rss"></i></a> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row copyright">
                    <div class="col-sm-6"> <span class="text-white">© <?php echo date('Y');?> baccans acomoodation system</span> </div>
                    <div class="col-sm-6">
                        <ul class="line-menu text-white hover-text-primary float-right">
                            <li><a href="#">Privacy & Policy</a></li>
                            <li>|</li>
                            <li><a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3646.768837738633!2d29.448495774535548!3d-23.933238378546122!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1ec6d797c3084113%3A0xe435804c7859b094!2s02%20Sabi%20St%2C%20Penina%20Park%2C%20Polokwane%2C%200699!5e0!3m2!1sen!2sza!4v1718957525343!5m2!1sen!2sza"> Site Map</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>